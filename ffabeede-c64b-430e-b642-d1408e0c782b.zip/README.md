# Microsoft Excel MCP Server

Offline MCP (Model Context Protocol) server for Microsoft Excel automation.
Built with `sbroenne/mcp-server-excel` v2.1.3.0 — self-contained .NET executable.

## Requirements

- Windows x64
- Microsoft Excel 2016 or later (desktop version) installed
- No .NET runtime install needed (self-contained)
- No Python / pip / internet needed

## Configuration

Edit the `env` block in `mcp.json`:

| Variable              | Description                                          | Default                                              |
| --------------------- | ---------------------------------------------------- | ---------------------------------------------------- |
| `EXCEL_INSTALL_PATH`  | Full path to `EXCEL.EXE` on your machine             | `C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE` |

Find your EXCEL.EXE:

- Office 365 / 2019 / 2021 / 2024 (64-bit):
  `C:\Program Files\Microsoft Office\root\Office16\EXCEL.EXE`
- Office 32-bit:
  `C:\Program Files (x86)\Microsoft Office\root\Office16\EXCEL.EXE`
- Older versions:
  `C:\Program Files (x86)\Microsoft Office\Office16\EXCEL.EXE`

## How it works

- `mcp-excel.exe` runs in **stdio MCP mode** (default, no args).
- The host (e.g. Kilo Code) pipes JSON-RPC to the process over stdin/stdout.
- The server drives Excel via the Windows COM automation API
  (`EXCEL_INSTALL_PATH` is set so the COM binding resolves to your install).

## Tools (31)

Analysis, calculation/eval, chart creation, data operations, Power Query,
VBA execution, workbook/sheet/range CRUD, and screenshot capture.
See the MCP server docs for the full list:
https://sbroenne.github.io/mcp-server-excel/
