---
name: excel-automation
display_name: Microsoft Excel Automation
description: >
  Offline Microsoft Excel automation via MCP. Drives a real Excel 2016+
  desktop install over stdio (COM) — workbook/sheet/range CRUD, formulas,
  charts, data operations, Power Query, VBA, and screenshots. No internet
  or .NET install required.
---

# Microsoft Excel Automation

The `excel` MCP server bundles a self-contained .NET exe (`mcp-excel.exe`,
v2.1.3.0 from `sbroenne/mcp-server-excel`). It talks MCP/JSON-RPC over
stdio and controls a locally-installed Excel via COM, so everything works
fully offline once the MCP host has launched the process.

## When to use

- Creating / editing / reading `.xlsx` / `.xlsm` files with real Excel
  semantics (formulas, pivots, charts), not openpyxl-style emulation.
- Running or inspecting VBA macros.
- Power Query (M) integration.
- Capturing a rendered screenshot of a worksheet range.

## Prerequisites

- Windows x64.
- Excel 2016+ desktop installed.
- `EXCEL_INSTALL_PATH` env var set to the full path of `EXCEL.EXE`
  (edit in `mcp.json`).

## Tool categories

| Category          | What it does                                                        |
| ----------------- | ------------------------------------------------------------------- |
| Analysis          | Summarize ranges: stats, uniques, nulls, duplicates.                 |
| Calculation       | Evaluate formulas / Excel expressions against live workbook data.    |
| Chart             | Create/edit charts (column, line, pie, …) bound to sheet data.        |
| Data              | Sort, filter, validate, lookup, fill, text transform on ranges.       |
| PowerQuery        | Run/list/modify Power Query (M) queries inside the workbook.          |
| VBA               | List modules, read/add/run macros, inspect the VBA project.            |
| Workbook ops      | Open/create/save/close workbooks, list sheets, manage workbook state. |
| Sheet ops         | Add/delete/rename sheets, set visibility, freeze panes, print areas.  |
| Range ops         | Read/write cells & ranges, styles, merged cells, column/row sizing.   |
| Screenshot        | Render a range to PNG (uses Excel's own rendering).                   |

## How to drive it

1. Ensure the MCP server named `excel` is registered (see `mcp.json`).
2. Call MCP tools via the normal tool-calling flow — the server spawns
   `mcp-excel.exe` on demand; stdio mode is the default (no args).
3. Typical workflow:
   - `open_workbook` (or `create_workbook`) with an absolute file path
   - `list_sheets`
   - read/write via range tools
   - evaluate formulas via calculation tools
   - `save_workbook` when done
   - `close_workbook` (Excel process is released automatically)
4. For VBA: `list_vba_modules` → `get_vba_code` → `run_vba_macro`.
5. For a rendered view: `screenshot_range` → PNG bytes.

## Notes

- One active workbook per server invocation is typical; close workbooks
  when finished to free the Excel COM handle.
- `EXCEL_INSTALL_PATH` only affects which Excel binary COM binds to —
  it is not used for any install-time work.
- The bundle is fully offline: the exe ships the .NET runtime, and Excel
  itself is already on the machine. No pip, no downloads, no venv.
